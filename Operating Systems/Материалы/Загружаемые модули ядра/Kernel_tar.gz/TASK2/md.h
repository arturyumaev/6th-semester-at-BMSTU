//#ifndef MY_MD
//#define MY_MD 1

extern char* md1_str_data;
extern int md1_int_data; 
extern char* md1_get_str(int n); 
extern int md1_factorial(int n);

//#endif
